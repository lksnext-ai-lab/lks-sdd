---
name: lks-sdd-verify
description: "Use with Codex. Verify implemented LKS-SDD tasks against exact acceptance and recoverable evidence, enforce configured quality and review rules, and distinguish closure, integration and acceptance."
---

# Verificar y cerrar

Respete el runtime fijado. Si falta el índice `.lks-sdd/project.json`, inspeccione
el Markdown antes de asumir un proyecto nuevo. Cargar esta skill no migra ni escribe.
Una garantía desconocida bloquea solo la porción afectada.

- Para formato **3.0 o 3.1**, lea [reglas comunes v3](../../docs/V3-COMMON.md) y
  [esta operación](references/v3.md).
- Para **2.0 o 1.5**, lea solo [procedimiento conservado](references/v2-and-legacy.md).
- Para un proyecto sin SDD, confirme configuración y use v3 si se solicita iniciar
  o adoptar; una consulta no inicializa nada.

Cargue únicamente la ruta aplicable. Al confirmar un hito, explique qué se ha hecho,
dónde queda el proceso, qué falta y la próxima acción. Si ya está autorizada, continúe.
