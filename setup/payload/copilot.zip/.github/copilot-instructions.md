<!-- LKS-SDD:BEGIN -->
# LKS-SDD in Copilot

Read `.github/lks-sdd-host.md` for LKS-SDD work.
For every application change, including an existing feature, reconcile the request with SPEC and complete PLAN/TASK before code. Follow the pinned runtime's docs/V2-SPEC-PLAN-TASK.md and report missing coverage.
Use the six skills and the pinned runtime; the installed plugin must respect the project lock.
<!-- LKS-SDD:END -->
