# Rendimiento de identidades y aprobaciones — 3.4.3-rc.2

La petición de 2026-10-14 autoriza esta corrección de la fuente oficial y su
verificación local. [El plan](plans/approval-performance/PLAN.md) conserva alcance,
decisiones, tareas y pendientes. No cambia el contrato, el método ni el esquema.

## Índices reconstruibles

`Model` mantiene en memoria un índice multivalor de UID/alias y otro por tipo.
Un mismo elemento cuyo alias coincide con su UID cuenta una vez; dos elementos
que comparten alias, o un alias que coincide con otro UID, conservan el error de
ambigüedad. La selección de tipo ocurre después de resolver la identidad. Las
referencias cualificadas siguen exigiendo el proyecto canónico correcto.

Los índices se reconstruyen perezosamente tras modificar el mapa `elements`,
sustituirlo, añadir, sustituir o eliminar entradas, o editar/reemplazar `Element.meta`.
Se observan los mutadores normales de diccionario, incluidos `update`, `setdefault`,
`pop`, `popitem`, `clear` y `|=`. Cambiar UID, alias o tipo invalida ambos índices.
No se guardan respuestas negativas. Los observadores usan referencias débiles;
copiar profundamente un elemento o un item produce un borrador independiente. `deepcopy(Model)`
reconstruye su tabla y observadores, sin reutilizar los índices de la fuente.
Las copias superficiales conservan la compartición normal y registran los nuevos
propietarios, incluidas las altas posteriores en una tabla compartida.

La auditoría de escrituras del runtime localiza la carga en `v3_contract._load`,
las altas/sustituciones prospectivas en `v31_review.overlay` y los datos resueltos
en `v3_inventories.resolve`. Authoring, gobierno, migración y reconciliación preparan
items independientes y vuelven a cargar staging; no alteran ocultamente el mapa.
`Model.at` y los lectores amplían `hashes`, el conjunto de fuentes leídas. Este
conjunto se mantiene separado de los índices semánticos.

## Reutilización durante una evaluación

`v3_evaluation.evaluation(model)` delimita una evaluación síncrona e inmutable de
un modelo. Los decoradores de aprobación, bases de tarea, cobertura y hechos abren
ese ámbito; las llamadas anidadas del mismo modelo lo reutilizan. Modelos diferentes
se aíslan por objeto, aunque tengan el mismo proyecto o UID. Un contexto heredado
por otra tarea asíncrona no comparte el estado mutable del padre. Tampoco se
comparten estados entre hilos, comandos ni evaluaciones sucesivas.

| Cálculo | Entradas | Reutilización |
|---|---|---|
| Pertenencias | Propuestas/features legacy y todas sus relaciones de ámbito | Un recorrido por evaluación mientras permanece admitido |
| Cierre global | Pertenencias, tipos, retirada, `global`, petición y dependencias completas | Un lector compartido |
| Descriptor | Lector global y secuencia de UID resueltos | Resultado por secuencia; copia defensiva en la API pública |
| Original heredado | Raíz del modelo, ruta física y hash esperado | Lectura, hash y análisis por ruta/hash; nunca por hash solo |

La guardia usa una revisión monótona, sin serializar el contrato en cada entrada
y salida. Se observan los metadatos completos (también estados, revisión, permisos
y revocaciones), cuerpos, rutas, líneas, datos resueltos, prosa, errores y avisos.
Los mapas y listas JSON anidados notifican antes de sus mutadores normales. Un
intento de cambio durante la evaluación incrementa la revisión y lanza `ContractError`
antes de editar; aunque el llamante capture el error, el ámbito y sus consultas
posteriores quedan invalidados. Restaurar el contenido no restaura la revisión.
Con varios propietarios compartidos se marcan todas sus revisiones antes de lanzar
el error, de modo que capturarlo no deja válido otro ámbito afectado.
Los campos y colecciones privados, y llamadas deliberadas a primitivas de base como
`dict.__setitem__` u `object.__setattr__`, no son APIs de edición admitidas.
Las mutaciones prospectivas ocurren antes de abrir el ámbito o después de cerrarlo.
Una evaluación nueva observa la nueva revisión. `hashes` crece con las lecturas
verificadas y conserva las comprobaciones físicas; no es una entrada semántica.

El modelo posee sus contenedores JSON observables. Los padres se enlazan débilmente;
desacoplar una rama no hace que su borrador invalide el modelo actual. Los inventarios
resueltos compartidos usan un único mapa observable por objeto físico en la carga,
con enlaces a sus eventos. La copia de un modelo conserva esa compartición dentro
de la copia y mantiene independencia respecto a la fuente. Las evaluaciones
simultáneas conservan su aislamiento; la guardia también rechaza una escritura
desde otro hilo mientras el modelo tiene una evaluación activa.

El almacenamiento temporal admite como máximo 256 entradas, 131.072 unidades
referenciadas (incluidas las claves de consulta) y 16 MiB de contenido de originales analizado. Aplica expulsión LRU y
omite la admisión de una entrada que excede el presupuesto; vuelve a calcularla sin
cambiar el resultado. Son límites de admisión de la reutilización, no un límite duro
de RSS de Python: el modelo, las estructuras de análisis, los observadores y
el resultado necesario siguen ocupando memoria. Permanecen los límites existentes
de contrato, lectura, inventarios, objetos y almacenamiento. Al salir, incluso por
excepción, se vacía el almacenamiento, se liberan sus referencias a modelo y tarea
asíncrona y se restaura el contexto. Las pertenencias públicas también se copian
para que modificar un resultado no altere cálculos posteriores. Las huellas de
originales se vuelven a observar en cada evaluación; un original modificado conserva
el resultado negativo de aprobación y las comprobaciones previas a materializar.

La aprobación tecnológica conserva el `all` de las decisiones individuales, con
`technology OR proposal` para cada tecnología. Unas pueden apoyarse en el primer
mecanismo y otras en el segundo. No se sustituye por una aprobación conjunta que
exija un mecanismo uniforme. El cierre y las obligaciones globales, fuentes inciertas,
dependencias y comprobaciones de revocación permanecen completos.

## Vigencia y materialización

Una evaluación opera sobre un snapshot en memoria, no bloquea ediciones externas.
Conserva cada ruta original y su hash en el conjunto de fuentes. `prepare` vuelve
a leer soportes, rechaza diferencias con las fuentes evaluadas y valida staging;
`apply` conserva comprobaciones frescas de precondiciones, inventarios, Git, sujeto,
caducidad, base confiable y transacción recuperable. Una caché de esta evaluación
no atraviesa esas fronteras. No se cachean permisos o decisiones entre comandos.
La prueba de cambio de original entre evaluación y preparación verifica el rechazo.

## Referencia y equivalencia

`tests/fixtures/approval-reference/manifest.json` vincula seis módulos originales
a 3.4.2 y al commit `a657bf7b07461c8b03516f9adbb00bb7a6b9ed7c`; `original.zip`
conserva sus bytes. El worker comprueba inventario y cada SHA-256 antes de importar.
Es un oráculo de pruebas inerte: ningún comando operativo lo selecciona como runtime
ni lo instala como una versión alternativa en consumidores.
Los demás módulos se comparten, sin modificaciones de comportamiento para este
experimento. Los procesos separados impiden mezclar imports de ambas versiones.

La comparación diferencial conserva resultados, errores, dependencias, fuentes,
decisiones, pendientes y descriptores. Los UUID generados usan una secuencia
determinista, el reloj de generación se fija antes de importar los módulos y ambos
workers usan `PYTHONHASHSEED=0` para fijar el orden de recorridos de conjuntos. En la
prueba focal solo se normaliza la raíz temporal declarada; no se borran campos.
El benchmark de operaciones usa las mismas rutas absolutas de fixture/staging/base
confiable en cada par, de modo que también compara íntegros los hashes de paquetes,
previews, receipts y resultados. No se confunde igualdad de contenido con aprobación
humana ni se afirma equivalencia para entradas no ensayadas.

## Reproducción y resultados

```powershell
python -B -X utf8 tests/run_unit_tests.py --module test_v3_approval_performance
python -B -X utf8 tests/measure_approval_performance.py `
  --sizes 100:5 500:15 1500:35 --repetitions 4 --cooldown 10 `
  --output output/approval-performance/measurement.json
python -B -X utf8 tests/measure_approval_performance.py `
  --sizes 1500:35 --repetitions 4 --order alternating --cooldown 10 `
  --phases shared-inventories --timeout 3600 `
  --output output/approval-performance/shared-inventories.json
```

El benchmark crea contratos temporales sintéticos con reglas globales compartidas,
tecnologías y features literales; mide carga/contexto, resolución, pertenencias,
dependencias, decisiones actuales/heredadas y preparación/aplicación de inicio,
implementación, evidencia, verificación, cierre, integración y aceptación. Conserva
muestras, medianas/rangos, contadores y memoria del proceso. La topología concreta
está declarada; 1.500/35 aproxima el volumen comunicado, no reproduce datos privados
ni garantiza la misma latencia. Los tiempos no son objetivos contractuales.
El runner es secuencial, equilibra el orden en cuatro pares y deja diez segundos
de reposo antes de cada proceso. Registra CPU y working set
muestreado cada 10 ms, además de picos acumulados y contadores. El caso adicional
conserva 80 eventos que comparten un inventario de 6.000 rutas, mide su carga y
el primer descriptor, y comprueba que no se multiplica el mapa resuelto.
Una auditoría CIM antes y después de cada worker rechaza otros runners de pruebas,
benchmark o perfilado conocidos de esta tarea. Se comprobó también el rechazo
ante un proceso de prueba. La auditoría queda fuera de los tiempos de operación;
no controla toda la actividad del sistema, su caché de disco o su frecuencia de CPU.
La CPU es la del proceso Python e incluye instrumentación y muestreo; no suma la
CPU de los procesos Git hijos. Los rangos y costes de carga permanecen visibles.

El [informe de implementación](plans/approval-performance/IMPLEMENTATION.md) registra
los resultados y sus límites. El benchmark es evidencia focal de esta corrección,
no una nueva batería obligatoria de release. No mide tokens facturados ni el recorrido
del asistente. Publicación, instalación y aceptación de host permanecen separadas.
