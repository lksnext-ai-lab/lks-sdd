<!-- LKS-SDD:BEGIN -->
# Shared LKS-SDD project contract

Both hosts use `.lks-sdd/runtime/3.0.0-4014676f0bd5` and its six skills. Check runtime-doctor before work.
Markdown is canonical; the index is derived. For every change reconcile SPEC, validate the concrete proposal, then complete PLAN/TASK before code. Follow the selected skill and docs/V3-COMMON.md in this runtime. Reuse valid decisions; do not migrate or publish implicitly.
<!-- LKS-SDD:END -->
