---
schema_version: "2.0"
artifact_type: "project"
---

# Origen publicado

<!-- lks-sdd: {"coverage":"partial","id":"PRJ-001","kind":"project","nature":"proposal","relations":{},"revision":1,"state":"draft","title":"Origen publicado","uid":"75dfad29-b043-51e3-959b-96411c40cd31"} -->
<a id="prj-001"></a>

## PRJ-001 · Origen publicado

La cobertura documentada es parcial. Defina el alcance del próximo cambio antes de planificar su implementación.
<!-- /lks-sdd -->
