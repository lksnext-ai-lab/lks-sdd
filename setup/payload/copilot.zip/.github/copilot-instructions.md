<!-- LKS-SDD:BEGIN -->
Read AGENTS.md and .github/lks-sdd-host.md for LKS-SDD 3.0. Use the pinned runtime's six skills for SPEC and PLAN/TASK; preserve all gates.
<!-- LKS-SDD:END -->
