---
name: lks-sdd-define
description: "Use with Codex. Define or evolve a human-readable LKS-SDD specification, decompose features and shared requirements, reconcile feature history and prepare a fully traced human-approved plan without generating application code; use the project-pinned document contract."
---

# Define with LKS-SDD

## Routing por contrato

For any requested application change, including an addition to an existing feature,
read [SPEC to PLAN/TASK continuity](../../docs/V2-SPEC-PLAN-TASK.md). Reconcile the
material request with the current SPEC, then update or reuse PLAN and TASK in the
same reviewed authoring transaction. A complete SPEC with missing TASK coverage is
still incomplete for implementation. Preserve a draft and explain the exact next
planning step if a critical decision is pending.

Read [v2 common policy and workflows](../../docs/V2-WORKFLOWS.md) for contract
2.0 or a new v2 project. Responsibility: Definir/evolucionar y conducir migración solicitada, sin código.
Use only the relevant section of that shared workflow and its linked references;
do not combine v2 syntax with the legacy workflow below. Existing projects remain
on their exact pinned runtime until explicitly migrated. Unknown schemas fail
closed; a question never initiates adoption, migration or implementation.

If the project is legacy 1.5, migration is a separate explicit workflow. Read
its diagnosis and exact preview before defining new scope; after cutover use
`migration-status` and `migration-continuation` so only the affected TASK is
held by unresolved semantics. Do not rewrite history or treat legacy records as
new v2 decisions.

## Workflow conservado para contrato 1.5

When explaining existing requirements/specifications and related tasks, read
`<plugin-root>/docs/PROJECT-QUERY.md`. A question alone stays read-only in help;
it never starts or resumes definition. Reuse its human presentation and sources
within an authorized definition without turning observations into approved scope.

When the intended stack differs from a reference, read
`<plugin-root>/docs/PROJECT-documented scope.md`. Keep the base binding as a
reference and document the actual composition. Offer the opt-in approval policy;
do not require global documented confirmation for every consumer documented scope or approve it yourself.

If `.lks-sdd/distribution-lock.json` exists, use its exact project-local runtime and
workflow instead of a different global version. Run `runtime-doctor` before work.
The invoking adapter identifies the host; folder presence does not. In native Codex,
follow the visual process below without handoff prompts or files. In Copilot, the
host adapter routes required image generation through the durable Codex handoff
described in `<plugin-root>/docs/VISUAL-HANDOFF.md`; no image API or provider key.
At resumption, inspect applicable `.lks-sdd/handoffs/visual/` requests read-only,
select the requested scope explicitly and validate returned results before closure.
An incoming handoff does not grant implementation authority or replace human approval.

The Markdown artifacts in the application repository are authoritative; `.lks-sdd/project.json` is only their operational index. Never turn a proposal, inference, or ambiguous answer into a decision.

1. Inspect the authorized root and current LKS-SDD state. If application code already exists and no materialized adoption baseline exists, stop definition changes and route the repository to `lks-sdd-adopt-existing`. Resume definition only after the adopted baseline is materialized and valid.
2. For a new or still ambiguous idea, read the [discovery interview](references/discovery-interview.md) before materializing an interpretation. Discover the professional domain, intended user, task/process/decision, inputs and rules with their source, and expected result. Ask adaptive batches of one to three questions with options explicitly labelled as proposals, plus `Otra` and `No lo sé todavía`; never silently turn an underspecified idea into a generic product.
3. Read [method](references/method.md) and [document contract](references/document-contract.md). Resolve `<plugin-root>` as the directory containing `.codex-plugin/plugin.json` for this installed skill; never resolve `scripts/` against the consumer project. Initialize only after the user explicitly requests creation, using `python "<plugin-root>/scripts/lks_sdd.py" define "<project-root>" --project-id <id>`; use `--dry-run` first when files may already exist. If initialization is requested before discovery is sufficient, keep unknowns and open points explicit instead of filling generic defaults.
4. Classify each contribution as fact, objective, requirement, restriction, proposal, decision, assumption, open point, risk, or evidence. Preserve provenance, uncertainty, and human edits. Maintain the qualitative table in `ART-STATUS` using the [definition coverage matrix](references/definition-coverage.md); assess sufficiency for the stated scope or increment and never calculate a global percentage.
5. Update only affected Markdown. If the core does not cover an applicable concern, read [conditional annexes](references/conditional-annexes.md) and materialize only the justified annex; never create empty documents to imply coverage. Show the compact definition summary after completing the initial framing, after completing a material functional block, after consolidating solution/UX/technical decisions, before recommending readiness, when a change reopens a sufficient dimension, when the user pauses, and on request. Do not repeat it after minor edits that add no orientation. Then ask one to three highest-impact questions and explain why they matter. The user may answer, defer, mark not applicable with a reason, or close the current detail level.
6. When a frontend or other user-facing interface is applicable, read [frontend design](references/frontend-design.md), materialize and maintain `ART-UX`, and complete the interface table in `ART-INCREMENTS`, including `Visual mode`. Define screens, per-screen detail and states, flows, dialogs, accessibility and visual direction before using ImageGen. With a sufficient brief, a material visual change and ImageGen available, generating between one and three proposals is required; normally compare two or three directions for a new application or material redesign, documenting why one is sufficient when comparison adds no value. One faithful prototype can extend an already confirmed direction. Generated PNG/JPG assets remain proposals until explicit human validation and must be stored or transferred under `docs/lks-sdd/03-solution/ui-prototypes/` and linked from Markdown. If ImageGen or repository write access is unavailable, set `Visual mode=pending` and `Visual prototype=pending` in `ART-INCREMENTS`, preserve the brief and impact in `ART-OPEN`, and do not create a fictitious `VIS-###` row; never claim that an asset exists.
7. Before G2, define the applicable delivery model (`bounded-release`, `continuous-evolution`, or `maintenance-stream`), product versioning, Git/branching model, CI/CD, environments, immutable promotion, deployment, recovery, and review triggers in `ART-GOVERNANCE`. Record later changes as new `CHG-###` entries; never rewrite history.
8. Compare technology only after requirements, architecture boundaries, and constraints. Read [technology selection](references/technology-selection.md). Select an exact closed local technology declaration per `UNIT-###` through a confirmed `BIND-###`; capabilities and families aid analysis and project documentation design but are not selectable or certified by themselves. Keep frontend and backend as separate units/bindings when their deployment boundaries differ. A candidate local technology declaration may document the exact decision and expose coverage, but it remains automation-unsupported until promoted; never replace Microsoft Entra with Keycloak or assemble an arbitrary dynamic local technology declaration to make a decision appear supported.
9. When an increment becomes sufficiently closed, automatically produce a transition summary with: completed and confirmed content; separate phase states; uncovered scope, acceptance, tests and dependencies; recommended next step; and the human decision needed. Never summarize a selected task as readiness of the whole release.
10. Before evaluating or materializing the first task plan in a project that has no confirmed tracking choice, ask whether the user wants `repository-only` planning in versioned Markdown, `jira-hybrid` planning with Jira Cloud as an operational projection of the same Markdown contract, or to pause. Do not offer Jira-only planning. The local option must remain a complete, professional product experience and must not prompt for Atlassian access. If Jira is chosen, separately confirm `projection-only` or `milestone-reporting` and an `advisory` or `required-before-execution` coordination gate. Recommend `milestone-reporting` plus `advisory` unless the team's governance requires Jira synchronization before starting. `ART-TRACKING` contains one project-level `TRK-###` and one reporting policy `RPT-###`; reuse them across planning horizons until the user explicitly asks to reconsider them. Record the choices through a human-confirmed `ADR-###`; choosing Jira does not authorize reading or writing Atlassian data.
11. Evaluate full-plan coverage with `python "<plugin-root>/scripts/lks_sdd.py" planning "<project-root>" --increment <INC-###> assess --json`. If it is `partial`, recommend completing the integral plan before implementation and present a preliminary decomposition outside the canonical contract. Offer three explicit choices: confirm and materialize the complete plan; plan only the next slice under a human-confirmed `incremental-authorized` ADR while retaining `partial`; or pause with a clear repository state. Do not turn the preliminary decomposition into decided tasks without confirmation.
12. After human confirmation, create or update `PLAN-###`, `REL-###`, `ART-PLANNING`, the task board, and one independent detail file per `TASK-###`. Each task needs objective, included/excluded scope, requirements, acceptance, tests, unit/binding, capabilities/gates, dependencies, parallelization, risks/blockers, responsible role, review conditions, definition of done, required evidence, integration responsibilities and concrete deliverables. Keep external-system and internal-interface INT tables distinct and optional; preserve IDs and reject duplicates. External systems do not require fictitious UNITs. For every material confirmed internal interface, declare its consumer/producer units, every binding, protocol/contract, exact operations, evidence scopes, primary owner, verification TASK and exact `local technology declaration@version`. The joint TASK must repeat all units/bindings in its structured table and depend on both endpoints; free text such as `Integration points` never satisfies this contract. A write requires persistence evidence for its declared resource. A joint web flow also requires `user-flow` and `GATE-BROWSER-FULLSTACK-E2E`; HTTP, PostgreSQL and migration tasks use their own observers. Select a system documented scope through `INT.Exact composition`, retaining separate API, SPA, database and migrator bindings. If no exact certified composition exists, keep that portion `automation_support=unsupported` and name documented confirmation or manual reconciliation as the next step. Do not invent people, dates, effort, velocity or capacity; record them as pending when required. In `jira-hybrid` mode, materialize and confirm this local plan before any Jira mutation, then read and follow the [Jira planning contract](references/jira-planning-contract.md): preview one TASK, search/read its marker with Rovo, persist the exact `SYNC-###` authorization before writing, execute one operation, reread marker/fingerprint and close that receipt by ID. Configure workflow mappings only from observed immutable Jira status IDs plus a confirmed decision; never infer a transition from status names.
13. Validate complete ownership of active scope, criteria and tests; no contradictory primary overlap; coherent release membership; an acyclic dependency graph; executable definitions; initial and parallel frontiers; and a joint release-verification task. Report structural order, but call the critical path `undetermined` unless confirmed durations exist. Confirm the resulting fingerprints only through preview/hash/apply and explicit human authorization using `planning ... confirm`; confirmation does not authorize implementation or an external Jira write.
14. Recommend `lks-sdd-assess-readiness` only when a concrete increment, its planning state, delivery governance, local technology declaration bindings and critical decisions are documented. An interface-affecting increment is not ready while its applicable UX contract or required visual validation remains pending.

En 0.18, diseña cada TASK de interfaz para que sus criterios, estados, temas e interacciones de riesgo puedan acreditarse con una a cinco capturas significativas. Si necesita más de cinco para no ocultar cobertura, divide o prioriza la TASK; no generes imágenes para completar una cuota. Mantén la revisión visual separada de la comunicación real, el flujo funcional y la persistencia.

Do not generate application code, infer authority, claim formal approval, or modify a repository merely because the user asked for an explanation. Do not create a seventh LKS-SDD skill, MCP, app, connector, hook or executable agent. `lks-sdd-define` owns the definition, ImageGen is only a conditional rendering capability, and Atlassian Rovo remains an independently installed optional companion rather than a bundled LKS-SDD component.

When selecting local-auth documented scope, treat architectural groups as descriptive, not selectable. Do not infer compatibility from version ranges or select a newer documented scope automatically.
