---
artifact_id: ART-{{TASK_ID}}
artifact_type: development-task
schema_version: "1.5"
method_version: "1.5.0"
created_with_plugin_version: "0.15.0"
project_id: "{{PROJECT_ID}}"
baseline_id: "{{BASELINE_ID}}"
status: draft
classification: internal
audience:
  - delivery-team
owners:
  - pending-assignment
source_of_truth: true
last_updated: "{{DATE}}"
---

# {{TASK_ID}} · {{TASK_TITLE}}

## Identidad

| Task | Plan | Release | Increment | Unit | Profile binding | Type |
|---|---|---|---|---|---|---|
| {{TASK_ID}} | {{PLAN_ID}} | {{RELEASE_ID}} | {{INCREMENT_ID}} | {{UNIT_ID}} | {{BINDING_ID}} | implementation |

## Definición ejecutable

| Objective | In scope | Out of scope | Requirements | Acceptance | Required capabilities | Technical gates | Dependencies |
|---|---|---|---|---|---|---|---|
| pending | pending | pending | pending | pending | pending | pending | not-applicable |

## Plan de ejecución verificable

| Tests | Decisions and constraints | Risks and blockers | Responsible role | Review entry conditions | Definition of done | Required evidence | Integration points | Parallel constraints |
|---|---|---|---|---|---|---|---|---|
| pending | pending | pending | pending-assignment | pending | pending | pending | pending | pending |

## Entregables

| Deliverable | State | Acceptance | Tests | Evidence | Notes |
|---|---|---|---|---|---|
| pending | pending | pending | pending | pending | pending |

## Alcance conjunto de integración

| Interface | Units | Profile bindings | Evidence scopes | Operations |
|---|---|---|---|---|

Complete esta tabla solo para una TASK responsable de `INT-###`. Debe repetir exactamente todas las unidades, bindings, scopes y operaciones del contrato de interfaz; no oculte participantes en texto libre.

## Ejecución y seguimiento

| Workflow state | Health | Progress | Owner | Branch | Revision start | Revision verified | Build | Environment | Updated |
|---|---|---|---|---|---|---|---|---|---|
| backlog | unknown | 0 | pending-assignment | pending | pending | pending | pending | pending | {{DATE}} |

## Problemas y bloqueos

| ID | State | Description | Impact | Owner | Resolution condition | Evidence |
|---|---|---|---|---|---|---|

## Validación

| Acceptance | Gate | Result | Evidence | Revision | Artifact digest | Environment |
|---|---|---|---|---|---|---|

## Continuidad

| Definition status | Current checkpoint | Authorization | Authorization scope | Specification fingerprint | Planning fingerprint | Next safe action |
|---|---|---|---|---|---|---|
| incomplete | none | none | none | pending | pending | complete task definition |

## Historial de cambios

| Date | From | To | Reason | Actor or authority | Evidence |
|---|---|---|---|---|---|

La tarea no está lista hasta que su aceptación, pruebas, dependencias, perfil/lock, gates, revisión, definición de terminado y evidencia sean resolubles. `done` exige evidencia ligada a la revisión y al artefacto realmente verificados. El porcentaje es secundario: la reanudación usa entregables, aceptación, checks y checkpoint concretos.
