# TASK-V3-007 · Ramas, sincronización e integración

Plan: [v3-plan-01](../PLAN.md). Estado: **pendiente; no autorizada para ejecutar**.
Responsabilidad: **Mantenimiento de integración Git**; persona/agente por asignar.
Dependencias: [TASK-V3-002](TASK-V3-002.md), [TASK-V3-003](TASK-V3-003.md), [TASK-V3-004](TASK-V3-004.md), [TASK-V3-005](TASK-V3-005.md), [TASK-V3-006](TASK-V3-006.md).

Requisitos de responsabilidad principal: REQ-EQT-013, REQ-EQT-014, REQ-EQT-015, REQ-EQT-018, REQ-EQT-020, REQ-EQT-026, REQ-EQT-063.
Casos de aceptación principales: AC-EQT-013, AC-EQT-016, AC-EQT-017, AC-EQT-018, AC-EQT-019, AC-EQT-025, AC-EQT-079, AC-EQT-080.

Leer las [reglas de ejecución](../EXECUTION.md) y las obligaciones literales asignadas
por la [matriz](../TRACEABILITY.md), incluidas sus dependencias aplicables.
La ficha concreta el trabajo; no sustituye la propuesta aprobada.

## Encargo y límites
Vincular cada petición a rama, destino configurado y base antes de materializar su
documentación; permitir ramas de especialistas y excepciones delimitadas. Implementar
comprobación local de referencias e integración semántica observable, sin locks remotos.

## Entregables e interfaces
- Añadir `scripts/v3_git.py` y `v3_integration_guard.py`, aprovechando lectura Git y
  guard de `v2_integration_guard.py` sin confiar en la política candidata como autoridad.
- Distinguir alias repetido, mismo UID modificado, intención duplicada y contradicción
  de reglas/contratos compartidos. Preparar reconciliación con decisión por impacto.
- Referencias acordadas de política/equipo/petición, commits y fecha observados, estado
  de conectividad y de recepción. Actualizar al iniciar/reanudar y antes de cerrar/integrar,
  según medios autorizados; no realizar un fetch por comando ni merge implícito.
- Vínculo de evidencia con commit/árbol/artefacto; conservar correspondencias tras
  squash, rebase, cherry-pick o retirada de ramas.
- Preparar información SDD del PR/candidato y reevaluación por composición; ninguna
  aprobación de PR, push o protección remota se deriva del resultado.

## Aceptación y evidencia
Usar repositorios temporales con dos clones y remoto local de pruebas. Documentación
nueva queda ligada a su petición/rama real. Un destino distinto de main y una integración
parcial se conservan correctamente. Merge textual limpio con contradicción se detecta.
Cambio de base o composición invalida solo evidencia afectada. Reasignación local no
figura como recibida; al compartir/reanudar se registra la revisión observada.
Desconexión limita acciones conforme a política; proyecto individual local no necesita
remoto. Entregar grafos Git, inventarios, diff y diagnósticos reproducibles.

## Riesgos y revisión
Una carrera posterior solo se detecta en la siguiente comprobación: no prometer exclusión
distribuida. Revisión del integrador y gobierno. Lectura adicional: rama/trazabilidad
funcional, técnica §5.2 y actuales funciones de guard/integración.
