"""Kafka stream processor reference."""
