<!-- LKS-SDD:BEGIN -->
# Shared LKS-SDD project contract

Both hosts use `.lks-sdd/runtime/3.1.0-98fc0af41216` and its six skills. Check runtime-doctor before work.
Markdown is canonical; the index is derived. For every change reconcile SPEC, validate the concrete proposal, then complete PLAN/TASK before code. Follow the selected skill and docs/V3-COMMON.md in this runtime. Reuse valid decisions; do not migrate or publish implicitly.
Before announcing implementation or editing application code, identify the validated SPEC, approved PLAN/TASK and current execution authority covering the actual request, and briefly report those references. If coverage is missing or scope changes, use define to record, validate and plan first. Reuse valid decisions; never infer missing documents or approvals from 'implement these changes'. Record deferred decisions and assess their impact before selecting an independent portion; critical unresolved decisions block the affected implementation. Any permitted process exception needs explicit competent validation, a reason and traceable scope.
<!-- LKS-SDD:END -->
