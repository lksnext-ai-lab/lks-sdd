import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";
export default defineConfig({plugins: [react()], test: {environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"], exclude: ["e2e/**", "verification/**", "node_modules/**", "dist/**"]}});
