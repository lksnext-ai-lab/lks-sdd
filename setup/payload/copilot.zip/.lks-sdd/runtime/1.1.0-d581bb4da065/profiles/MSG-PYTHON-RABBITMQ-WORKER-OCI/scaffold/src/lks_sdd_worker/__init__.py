"""RabbitMQ message worker reference."""
