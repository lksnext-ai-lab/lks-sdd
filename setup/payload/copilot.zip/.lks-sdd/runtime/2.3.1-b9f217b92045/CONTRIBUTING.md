# Contribución a LKS-SDD

## Alcance

La versión `0.15.0` conserva M0–M5 y el contrato 1.5 como release candidate técnica para Codex. Mantiene 1.0–1.5 en compatibilidad, los perfiles Microsoft Entra como candidates y añade dos perfiles OIDC simulados active certificados exclusivamente para entornos no productivos, sin composición dinámica. Una contribución puede mejorar las seis skills, contratos, perfiles, harness, distribución candidate o infraestructura de piloto. M5 queda preparado pero no ejecutado; la numeración SemVer `0.15.0` no significa que M6, la publicación estable, la interoperabilidad real o el soporte corporativo estén completados o aprobados.

## Contrato de cambio

1. Describir el problema y separar hechos, inferencias, propuesta y decisión requerida.
2. No editar `specs/canonical/` para acomodar una implementación.
3. Mantener los Markdown consumidores como fuente canónica y el índice como navegación operativa.
4. Preservar ediciones humanas, invocación implícita y límites de autorización.
5. Añadir o ajustar una prueba que observe el comportamiento relevante.
6. Ejecutar `docs/VALIDATION.md` y revisar el diff completo.
7. Documentar compatibilidad, migración o incompatibilidad cuando cambie un contrato.
8. Seguir `docs/RELEASING.md` cuando el cambio cierre una versión publicable.
9. Actualizar el catálogo, el manifiesto de fixtures o la baseline de comparación cuando el cambio altere la evidencia M4 correspondiente.
10. Mantener cualquier configuración y evidencia real del piloto fuera del repositorio; solo se versionan contratos, ejemplos vacíos y resultados agregados expresamente saneados.
11. Cuando una evolución funcional amplíe el contrato, añadir una fuente versionada y su hash sin reescribir fuentes canónicas anteriores; cuando exista solo deriva, corregir implementación y evidencia.
12. Mantener los activos visuales del proyecto consumidor ligados a Markdown canónico, con estado y procedencia; no tratar una generación de ImageGen como aprobación humana ni como prueba de accesibilidad.
13. Mantener sincronizados `method_version: 1.5.0`, `schema_version: 1.5`, el catálogo declarativo, las plantillas y los diagnósticos; 0.15 no distribuye validación ni migradores de proyectos 1.0–1.4.
14. Separar en contrato, ayuda y pruebas la preparación funcional de la especificación del soporte de automatización. Una limitación de perfil no debe degradar la suficiencia documental ni provocar una selección tecnológica automática.
15. Probar la trazabilidad en `preimplementation` y `verification`: la primera termina en `TEST-###`; la segunda exige además una `EVID-###` ejecutada y aplicable. Un alcance vacío no puede superar ninguna fase.
16. Ejecutar los comandos sobre proyectos consumidores mediante `python "<plugin-root>/scripts/lks_sdd.py" <comando> "<project-root>"`; `<plugin-root>` es la instalación que contiene el manifiesto, no el proyecto consumidor.
17. Conservar `skipped` y `not-run` como estados no superados. Solo los canales opcionales del gate candidate pueden permanecer sin ejecutar; todos los canales requeridos por `stable` necesitan evidencia real y estado satisfactorio.
18. Mantener las capabilities como contratos explicativos y los perfiles exactos como única unidad seleccionable/certificable; no declarar soporte parcial, composición dinámica ni sustitución de proveedor.

## Revisión

Todo cambio necesita revisión humana antes de integrarse. Cambios de método, esquema, seguridad, privacidad, licencia, distribución o perfil tecnológico requieren además la decisión correspondiente indicada en `GOVERNANCE.md`. Un resultado de test no constituye esa aprobación.

No se deben incluir secretos, datos reales de clientes ni contenido sustantivo de proyectos consumidores. Los fixtures deben ser sintéticos.
