---
schema_version: "2.0"
artifact_type: "applicability"
---

# Aplicabilidad del cambio

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"ux","id":"APP-001","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"ux","uid":"88b75ebb-0be0-5f6b-9009-16d51b472a77"} -->
<a id="app-001"></a>

## APP-001 · ux

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"data","id":"APP-002","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"data","uid":"9a30b6c5-20eb-5423-a5d1-e05480dd2fac"} -->
<a id="app-002"></a>

## APP-002 · data

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"identity","id":"APP-003","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"identity","uid":"2be25ec3-183a-5203-8a80-c15545627d57"} -->
<a id="app-003"></a>

## APP-003 · identity

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"security","id":"APP-004","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"security","uid":"c23ac5eb-b78f-5210-91e8-efc8d553a614"} -->
<a id="app-004"></a>

## APP-004 · security

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"privacy","id":"APP-005","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"privacy","uid":"e09821c7-cff9-59a4-8443-ab26ca0c4f25"} -->
<a id="app-005"></a>

## APP-005 · privacy

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"interfaces","id":"APP-006","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"interfaces","uid":"0de2bbf1-aef6-51df-ba10-7d0465778171"} -->
<a id="app-006"></a>

## APP-006 · interfaces

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"quality","id":"APP-007","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"quality","uid":"c04525c8-a580-58c8-93f6-cc1f90090b2c"} -->
<a id="app-007"></a>

## APP-007 · quality

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->

<!-- lks-sdd: {"applicability":"unknown","critical":true,"domain":"operation","id":"APP-008","kind":"applicability","nature":"unknown","relations":{},"revision":1,"scope":"global","state":"unknown","title":"operation","uid":"8e7191f2-7f57-57f5-8970-1f97a3a394ba"} -->
<a id="app-008"></a>

## APP-008 · operation

Pendiente de determinar para el ámbito solicitado.
<!-- /lks-sdd -->
