# GitHub Copilot host contract

VS Code Agent adapter; not a VSIX. `<plugin-root>` is `.lks-sdd/runtime/3.1.0-98fc0af41216`.
Run `python .lks-sdd/runtime/3.1.0-98fc0af41216/scripts/lks_sdd.py runtime-doctor . --json`; failure blocks
affected work. Use available host tools for the shared six workflows and gates.
Respect the lock's plugin/project entrypoints; never load both or switch runtimes
silently. `$skill` names identify workflows, not mandatory Copilot syntax.

For 1.5/2.0 load `.lks-sdd/runtime/3.1.0-98fc0af41216/docs/HOST-COPILOT-DETAILS.md`. For 3.0 load only its
applicable section when visual/external capabilities are needed. Missing tools
stay not-run. Do not configure MCP, hooks, agents, providers or personal settings;
never fabricate evidence or substitute an image provider silently.
