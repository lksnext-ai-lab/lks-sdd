# GitHub Copilot host contract

VS Code Agent adapter; not a VSIX. `<plugin-root>` is `.lks-sdd/runtime/3.4.0-ce6340ae9b38`.
Run `python .lks-sdd/runtime/3.4.0-ce6340ae9b38/scripts/lks_sdd.py runtime-doctor . --json`; failure blocks
affected work. Use available host tools for the shared six workflows and gates.
Respect the lock's plugin/project entrypoints; never load both or switch runtimes
silently. `$skill` names identify workflows, not mandatory Copilot syntax.

For 1.5/2.0 load `.lks-sdd/runtime/3.4.0-ce6340ae9b38/docs/HOST-COPILOT-DETAILS.md`. For 3.0 load only its
applicable section when visual/external capabilities are needed. Missing tools
stay not-run. Do not configure MCP, hooks, agents, providers or personal settings;
never fabricate evidence or substitute an image provider silently.
