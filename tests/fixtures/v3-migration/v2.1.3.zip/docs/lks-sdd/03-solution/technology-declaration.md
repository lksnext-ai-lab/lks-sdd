---
schema_version: "2.0"
artifact_type: "technology-declaration"
---

# Declaración tecnológica local

La declaración es local al proyecto. Una observación o una propuesta no equivale a una selección confirmada.

<!-- lks-sdd: {"id":"TECH-001","kind":"technology","nature":"unknown","relations":{},"revision":1,"state":"unknown","technology":{"critical":true,"evidence":[{"kind":"consumer-document","path":"docs/lks-sdd/01-context/project.md","sha256":"bdb24674a0f55133bc7e2bfe92c189f5d24dee41454c94ffcd3e2464c92619c8"}],"provenance":[],"scope":["global"],"state":"unknown","subject":"project technology decision"},"title":"Tecnología pendiente de confirmar","uid":"e8699900-1b13-5d3a-8137-139b06fef59a"} -->
<a id="tech-001"></a>

## TECH-001 · Tecnología pendiente de confirmar

No se presume una pila tecnológica. Registre observaciones locales y confirme una decisión antes de usarla para preparar trabajo.
<!-- /lks-sdd -->
