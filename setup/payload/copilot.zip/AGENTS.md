<!-- LKS-SDD:BEGIN -->
# Shared LKS-SDD project contract

Markdown under docs/lks-sdd is authoritative; .lks-sdd/project.json is an index.
Read .lks-sdd/distribution-lock.json. Both hosts use its exact runtime and workflows.
Runtime: `.lks-sdd/runtime/1.1.0-d581bb4da065`. Before work run `python .lks-sdd/runtime/1.1.0-d581bb4da065/scripts/lks_sdd.py runtime-doctor . --json`.
If integrity fails, stop affected work; do not fall back to a global plugin.
The active host comes from the current tool/adapter, never from folder presence.
In Codex read the pinned skills/<skill>/SKILL.md from this runtime. Native Codex image work proceeds normally without handoff announcements or files.
In Copilot load .github/lks-sdd-host.md and use the installed plugin skills or project skills according to distribution-lock.json entrypoints. Never load both.
At resumption inspect `.lks-sdd/handoffs/visual/` if present; select the requested scope explicitly. Read/status/help must not write. Validate any received result.
One writer per shared scope; transfer changes and assets through your approved Git workflow before another developer resumes. Never share credentials or chat sessions.
Prototype approval is not implementation authorization. Preserve human decisions, AUTH, EXEC, CKPT, EVID and all existing gates. No automatic commit, push or remote write.
<!-- LKS-SDD:END -->
