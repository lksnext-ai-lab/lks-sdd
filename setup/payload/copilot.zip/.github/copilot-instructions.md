<!-- LKS-SDD:BEGIN -->
# LKS-SDD in Copilot

Read `.github/lks-sdd-host.md` for LKS-SDD work.
Use the six skills and the pinned runtime; the installed plugin must respect the project lock.
<!-- LKS-SDD:END -->
