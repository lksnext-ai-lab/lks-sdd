#!/usr/bin/env python3
"""Stable command dispatcher for scripts bundled with the LKS-SDD plugin."""

from __future__ import annotations

import argparse
import json
import runpy
import sys
from pathlib import Path

if str(__file__).startswith("\\\\?\\"):
    _bootstrap = Path(__file__).with_name("import_bootstrap.py")
    _namespace = {}
    exec(compile(_bootstrap.read_bytes(), str(_bootstrap), "exec"), _namespace)
    _namespace["ensure_import_path"](__file__)
    del _bootstrap, _namespace

# A query may run from a consumer-local pinned runtime. Disable bytecode before
# importing any plugin module, not only after dispatching to query_project.
sys.dont_write_bytecode = True
from path_utils import filesystem_root, same_filesystem_path


PLUGIN_ROOT = filesystem_root(Path(__file__).resolve().parents[1])
COMMANDS = {
    "usage-inspect": "scripts/usage_bundle.py",
    "usage-export": "scripts/usage_bundle.py",
    "v3": "scripts/v3_cli.py",
    "v2": "scripts/v2_cli.py",
    "catalog": "scripts/v2_cli.py",
    "context": "scripts/v2_cli.py",
    "history": "scripts/v2_cli.py",
    "migrate": "scripts/v2_cli.py",
    "query": "scripts/query_project.py",
    "help": "skills/lks-sdd-help/scripts/context_help.py",
    "define": "skills/lks-sdd-define/scripts/init_project.py",
    "adopt-inspect": "skills/lks-sdd-adopt-existing/scripts/inspect_repository.py",
    "adopt-validate": "skills/lks-sdd-adopt-existing/scripts/validate_adoption.py",
    "adopt-materialize": "skills/lks-sdd-adopt-existing/scripts/materialize_adoption.py",
    "assess-readiness": "skills/lks-sdd-assess-readiness/scripts/assess_readiness.py",
    "implement": "skills/lks-sdd-implement/scripts/prepare_increment.py",
    "verify": "skills/lks-sdd-verify/scripts/run_verification.py",
    "tasks": "scripts/manage_tasks.py",
    "planning": "scripts/manage_planning.py",
    "tracking": "scripts/manage_task_tracking.py",
    "continuity": "scripts/manage_continuity.py",
    "validate-project": "scripts/validate_project.py",
    "validate-spec": "scripts/validate_spec.py",
    "traceability": "scripts/check_traceability.py",
    "client-view": "scripts/render_client_view.py",
    "status": "scripts/project_status.py",
    "work": "scripts/work_task.py",
    "doctor": "scripts/doctor_project.py",
    "runtime-doctor": "scripts/runtime_doctor.py",
    "visual-handoff": "scripts/manage_visual_handoff.py",
}


def runtime_failure(payload, command, forwarded):
    from v3_usage import early
    capture=None;capture_error=None;input_raw=None;options={}
    if command=="v3":
        from diagnostic_capture import early_options, early_consumer, Capture
        options=early_options(forwarded)
        if options.get("--capture-dir"):
            try:
                capture=Capture(options["--capture-dir"],early_consumer(forwarded))
                if options.get("--input"):
                    from v3_contract import read_bytes
                    source=Path(options["--input"]).resolve()
                    input_raw=read_bytes(source.parent,source.name,limit=64*1024*1024,package_data=True)
            except (OSError,ValueError,KeyError,TypeError) as exc:capture_error=str(exc)
    result = early(payload, command, {"arguments": forwarded},context={"run_id":capture.run_id} if capture else None)
    original=dict(result)
    if command == "v3":
        from v3_cli_presentation import operational_requested, usage_view
        if operational_requested(forwarded): result["usage"] = usage_view(result["usage"])
    if options.get("--capture-dir"):
        from diagnostic_capture import emit
        emit(result,original,capture,capture_error,argv=forwarded,input_raw=input_raw)
    else: print(json.dumps(result, ensure_ascii=False))


def main() -> int:
    if len(sys.argv) > 2 and sys.argv[1] == "v3" and "--activity" in sys.argv[2:]:
        from v4_activity import session
        # Observe runtime admission too; cooperative signal ownership starts in
        # the shared V4 CLI, after this read-only bootstrap has admitted it.
        with session("bootstrap", activity=True): return _main()
    return _main()


def _main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="strict")
    parser = argparse.ArgumentParser(
        description=(
            "Punto de entrada portable. Use la ruta absoluta de este archivo desde "
            "la instalación del plugin y pase después los argumentos del comando."
        )
    )
    parser.add_argument("command", choices=tuple(COMMANDS))
    if len(sys.argv) == 1 or sys.argv[1] in {"-h", "--help"}:
        parser.print_help()
        return 0
    command = sys.argv[1]
    if command not in COMMANDS:
        parser.error(
            f"argument command: invalid choice: {command!r} "
            f"(choose from {', '.join(repr(item) for item in COMMANDS)})"
        )
    forwarded = sys.argv[2:]
    # Public historical aliases cannot continue writing an older contract with this runtime.
    if command in {"define", "implement", "verify", "adopt-materialize", "planning", "tracking", "continuity", "tasks", "work"}:
        for argument in forwarded[:2]:
            if argument.startswith("-"): continue
            candidate = Path(argument)
            if candidate.is_dir() and (candidate/".lks-sdd/project.json").is_file():
                try: schema = json.loads((candidate/".lks-sdd/project.json").read_bytes())["schema_version"]
                except (ValueError, KeyError): schema = "unknown"
                action = forwarded[1] if len(forwarded) > 1 else ""
                query = command in {"planning", "tracking", "continuity", "tasks", "work"} and any(a in {"status", "board", "assess", "next", "diff"} for a in forwarded[:2])
                if schema in {"3.0", "3.1"} and command in {"planning", "tracking", "continuity", "tasks", "work"}:
                    print(json.dumps({"status": "blocked", "error": "Use lks_sdd.py v3 --help; an older writer cannot modify v3", "writes": []}))
                    return 2
                if schema not in {"3.0", "3.1"} and not query:
                    print(json.dumps({"status": "blocked", "error": "needs-migration: current work requires method 3.1.0; use v3 migration-diagnose", "writes": []}))
                    return 2
                break
    # Legacy public work commands used action/root; accept both without ever
    # dispatching a v2 project into a writer for the table-based 1.5 contract.
    if command in {"work", "tasks", "planning", "continuity", "tracking"} and len(forwarded) > 1:
        from v2_cli import is_v2
        candidate = Path(forwarded[1])
        if not forwarded[0].startswith("-") and candidate.is_dir() and is_v2(candidate):
            forwarded = [forwarded[1], forwarded[0], *forwarded[2:]]
    # A shared project never silently runs a different global installation.
    migration_route = command == "migrate" or (command == "v3" and forwarded and forwarded[0] in {
        "migration-diagnose", "migration-preview", "configure-collaboration", "apply", "recover", "rollback", "usage-report", "usage-export"}) or (command == "v2" and forwarded and forwarded[0] in {
        "migration-diagnose", "migration-preview", "migration-status", "migration-continuation",
        "migrate", "recover", "rollback", "method-upgrade-diagnose", "method-upgrade"})
    if command not in {"runtime-doctor", "query", "usage-export", "usage-inspect"} and not migration_route:
        from runtime_doctor import check as check_runtime
        for argument in forwarded:
            if argument.startswith("-"):
                continue
            try:
                candidate = filesystem_root(Path(argument))
                locked = candidate.is_dir() and (candidate / ".lks-sdd/distribution-lock.json").is_file()
            except (OSError, ValueError):
                continue
            if not locked:
                continue
            runtime = check_runtime(candidate)
            if runtime["status"] == "blocked":
                runtime_failure(runtime, command, forwarded)
                return 2
            pinned = (candidate / runtime["runtime"]).resolve()
            if not same_filesystem_path(pinned, PLUGIN_ROOT):
                from v3_current import FORMATS
                lock = json.loads((candidate / ".lks-sdd/distribution-lock.json").read_bytes())
                if lock["project_schema"] in {"2.0", "3.0", "3.1"} and not set(FORMATS) <= set(lock.get("storage_formats", [])):
                    runtime_failure({"status": "blocked", "error": "needs-runtime-update: prepare the explicit current-method cutover; the older pinned CLI is for read-only access/recovery",
                                      "next": f"python {PLUGIN_ROOT / 'scripts/lks_sdd.py'} v3 migration-diagnose {candidate} --json",
                                      "read_only_cli": str(pinned / "scripts/lks_sdd.py"), "writes": []}, command, forwarded)
                    return 2
                runtime_failure({"status": "blocked", "error": "Use the exact project-pinned CLI and workflows",
                                  "cli": str(pinned / "scripts/lks_sdd.py")}, command, forwarded)
                return 2
            break
    if command not in {"v3", "usage-export", "usage-inspect"} and forwarded:
        from v3_cli import is_v3, main as v3_main
        if Path(forwarded[0]).is_dir() and is_v3(Path(forwarded[0])):
            routes = {"help": "status", "status": "status", "query": "status", "doctor": "validate", "validate-project": "validate",
                      "validate-spec": "validate", "assess-readiness": "readiness", "define": "author", "implement": "start",
                      "verify": "verify", "context": "context", "traceability": "trace", "catalog": "catalog", "history": "history"}
            if command in routes: return v3_main(forwarded, command=routes[command])
            if command not in {"runtime-doctor", "visual-handoff"}:
                print(json.dumps({"status": "blocked", "error": "Use lks_sdd.py v3 --help; an older writer cannot modify v3"}))
                return 2
    if command in {"catalog", "context", "history", "migrate"}:
        from v2_cli import main as v2_main
        return v2_main(forwarded, command=command)
    if command not in {"v2", "query", "runtime-doctor", "visual-handoff", "usage-export", "usage-inspect"} and forwarded and not forwarded[0].startswith("-"):
        from v2_cli import is_v2, main as v2_main
        project = Path(forwarded[0])
        if command == "define" and project.is_dir() and not (project / ".lks-sdd/project.json").exists():
            print(json.dumps({"status": "needs-configuration", "next": "Use v3 init with the confirmed process, owner, controls, collaboration and compatible runtime_bundle."}))
            return 2
        if project.is_dir() and is_v2(project):
            route = {"validate-project": "validate", "validate-spec": "validate", "assess-readiness": "readiness",
                     "implement": "start", "verify": "verify", "status": "status", "doctor": "validate",
                     "help": "status", "client-view": "catalog", "define": "author", "traceability": "context"}
            if command in route:
                return v2_main(forwarded, command=route[command])
            if command in {"tasks", "work", "planning", "continuity", "tracking"}:
                action = forwarded[1] if len(forwarded) > 1 and not forwarded[1].startswith("-") else "status"
                action_route = {"status": "status", "board": "status", "assess": "readiness", "next": "readiness",
                                "authorize": "authorize", "start": "start", "resume": "resume", "checkpoint": "checkpoint",
                                "review": "checkpoint", "verify": "verify", "close": "close", "diff": "diff",
                                "prepare": "prepare", "problem": "problem", "correct": "correct", "replan": "replan", "revoke": "revoke"}
                if command == "tracking":
                    action_route = {a: "tracking-" + a for a in ("status", "project", "authorize", "result", "reconcile")}
                if action not in action_route:
                    print(json.dumps({"status": "blocked", "error": "Use the documented v2 command for this transition"}))
                    return 2
                arguments = [forwarded[0], *(forwarded[2:] if len(forwarded) > 1 and forwarded[1] == action else forwarded[1:])]
                if action == "review":
                    arguments += ["--state", "in-review"]
                return v2_main(arguments, command=action_route[action])
            if command not in {"query", "runtime-doctor", "visual-handoff"}:
                print(json.dumps({"status": "blocked", "error": "This legacy command does not write contract 2.0; use lks_sdd.py v2 --help"}))
                return 2
    target = (PLUGIN_ROOT / COMMANDS[command]).resolve()
    try:
        target.relative_to(PLUGIN_ROOT)
    except ValueError:
        parser.error("El comando resuelto queda fuera del plugin.")
    if not target.is_file():
        parser.error(f"Falta el ejecutable empaquetado: {COMMANDS[command]}")
    original_argv = sys.argv
    original_path = list(sys.path)
    try:
        sys.argv = [str(target), *([command] if command in {"usage-inspect", "usage-export"} else []), *forwarded]
        sys.path.insert(0, str(target.parent))
        runpy.run_path(str(target), run_name="__main__")
    except SystemExit as exc:
        return int(exc.code or 0)
    finally:
        sys.argv = original_argv
        sys.path[:] = original_path
    return 0


if __name__ == "__main__":
    sys.exit(main())
